//
//  ViewController.swift
//  SafeSync
//
//  Created by M Usman Haider on 24/01/2022.
//

import UIKit
import Firebase
import FirebaseAuth
import CodableFirebase
class ViewController: UIViewController {
    let usersRef = Database.database().reference(withPath: "users")
    var handle: AuthStateDidChangeListenerHandle?
    var user: User = User() {
        didSet {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(user) {
                let defaults = UserDefaults.standard
                defaults.set(encoded, forKey: "saveUser")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = true
        
        // 1
//        handle = Auth.auth().addStateDidChangeListener { _, user in
//          // 2
//          if user == nil {
//
//          } else {
//              self.usersRef.child(user?.uid ?? "").observeSingleEvent(of: .value, with: { snapshot in
//                  guard let value = snapshot.value else { return }
//                  do {
//                      var model = try FirebaseDecoder().decode(User.self, from: value)
//                      if model.devices == nil {
//                          model.devices = [Watch]()
//                      }
//                      self.user = model
//
//                      let vc = self.storyboard?.instantiateViewController(withIdentifier: "MainVc") as! MainVc
//                      vc.modalPresentationStyle = .fullScreen
//                      self.present(vc, animated: true, completion: nil)
//
//                  } catch let error {
//                      print(error)
//                  }
//              })
//          }
//        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    @IBAction func signIn(_ sender: UIButton) {
    }
    
    @IBAction func signUp(_ sender: UIButton) {
    }
}

