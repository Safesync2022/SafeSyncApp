//
//  HomeVc + Location.swift
//  SafeSync
//
//  Created by Attique Ullah on 10/02/2022.
//

import Foundation
import UIKit
import SwiftLocation
import Alertift
import CoreLocation
import Firebase
extension HomeVc {
    
    func setUpLocationServices() {
        
        self.serviceOptions.accuracy = GPSLocationOptions.Accuracy.city
        self.serviceOptions.activityType = .fitness
        self.serviceOptions.precise = .reducedAccuracy
        self.serviceOptions.minDistance = CLLocationDistance(0)
        self.serviceOptions.subscription = .continous
        
        SwiftLocation.requestAuthorization(.onlyInUse) { [weak self] newStatus in
            switch newStatus {
            case .authorizedWhenInUse:self?.createLocationRequest()
            case .notDetermined: break
            case .denied:self?.displayLocationAlert()
            case .authorizedAlways:self?.createLocationRequest()
            case .restricted:self?.displayLocationAlert()
            @unknown default:
                break
            }
        }
    }
    func createLocationRequest(){
        let request = SwiftLocation.gpsLocationWith(serviceOptions)
        request.then(queue: .main) { result in
            switch result {
            case .success(let visit):self.collectLocation(location: visit)
            case .failure(let error):print(error)
            }
        }
    }
    private func displayLocationAlert(){
        Alertift.alert(title: "Location Services Disabled", message: "Would you like to change this in settings?")
            .action(.default("Yes")) {
                UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
            }
            .action(.cancel("Cancel"))
            .show()
    }
    func collectLocation(location: CLLocation){
        self.userLocation = location
        
        if self.user?.devices?.count == 0 {
            return
        }
        
        let queue = OperationQueue()
        queue.qualityOfService = .userInitiated
        queue.maxConcurrentOperationCount = self.user?.devices?.count ?? 0
        
        self.handles.removeAll()
        geofireRef.removeAllObservers()
        
        var operations:[HomeOperation] = []
        for watch in self.user?.devices ?? [] {
            let operation = HomeOperation(watch: watch, location: location)
            let handle = observeConversationUpdated(watch: watch)
            operations.append(operation)
            self.handles.append(handle)
        }
        
        handleViewsStateForOperations(operations: operations, onOperationQueue: queue)
        queue.addOperations(operations, waitUntilFinished: false)
    }
    
    private func observeConversationUpdated(watch: Watch) -> UInt {
        return geofireRef.observe(.childChanged, with: { [weak self] snapshot in
            guard let self = self else { return }
            if snapshot.exists() {
                var device = self.user?.devices?.filter({$0.uid == snapshot.key}).first
                let location = (snapshot.value as! [String:Any])["l"] as? [Double] ?? []
                let center = CLLocation(latitude: location.first ?? 0.0, longitude: location.last ?? 0.0)
                let userRadius = self.userLocation?.distance(from: center)
                device?.distance = userRadius
                DispatchQueue.main.async {
                    self.updateData(device: device!)
                }
            }
        }) { error in
            
        }
    }
    
    private func handleViewsStateForOperations(operations:[Operation], onOperationQueue queue:OperationQueue) {
        operations.forEach { operation in
            switch operation {
                /* ------------------------------------------------------------------------------------------------------------ */
                //MARK: Start New Conversation Operation completion
                case let operation as HomeOperation:
                    operation.completionBlock = {
                        guard case let .success(watch) = operation.result else {
                            if case let .failure(error) = operation.result {
                                print(error)
                            }
                            return
                        }
                        DispatchQueue.main.async {
                            self.updateData(device: watch)
                        }
                        self.sendPushNotifications(device: watch)
                        
                }
                default: break
            }
        }
    }
    
    
    
    private func showAlert(withErrorMessage message:String, cancellingOperationQueue queue:OperationQueue, completion: (() -> Void)? = nil) {
        DispatchQueue.main.async {
            Alertift.alert(title: "Error", message: message)
                .action(.default("OK")) {
                    if let completionHandler = completion { completionHandler() }
                }
                .action(.cancel("Cancel")) {
                    queue.cancelAllOperations()
                }
                .show()
        }
    }
}
