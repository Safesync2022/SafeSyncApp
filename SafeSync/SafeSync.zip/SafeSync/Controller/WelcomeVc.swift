//
//  WelcomeVc.swift
//  SafeSync
//
//  Created by M Usman Haider on 25/01/2022.
//

import UIKit

class WelcomeVc: UIViewController {
    
    
    @IBOutlet weak var selectLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = false
    }
    
    @IBAction func dropBtn(_ sender: UIButton) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainVc") as! MainVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
