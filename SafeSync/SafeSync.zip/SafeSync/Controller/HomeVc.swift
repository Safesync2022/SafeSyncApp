//
//  HomeVc.swift
//  SafeSync
//
//  Created by M Usman Haider on 24/01/2022.
//

import UIKit
import BarcodeScanner
import Firebase
import CodableFirebase
import Alertift
import SwiftLocation
import CoreLocation

class tablecell: UITableViewCell {
    @IBOutlet weak var img : UIImage!
    @IBOutlet weak var watchName : UILabel!
    @IBOutlet weak var lblDistance : UILabel!
    @IBOutlet weak var desLabel : UILabel!
}

class HomeVc: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    @IBOutlet weak var tableViewWatch: UITableView!
    
    var serviceOptions = GPSLocationOptions()
    var handles: [UInt] = []
    var userLocation:CLLocation?
    
    let devicesRef = Database.database().reference(withPath: "Devices")
    let usersRef = Database.database().reference(withPath: "users")
    let geofireRef = Database.database().reference(withPath: "Locations")
    
    
    
    var user: User? {
        get {
            let defaults = UserDefaults.standard
            if let savedPerson = defaults.object(forKey: "saveUser") as? Data {
                let decoder = JSONDecoder()
                if let loadedPerson = try? decoder.decode(User.self, from: savedPerson) {
                    return loadedPerson
                }
            }
            return nil
        }
        set {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(newValue) {
                let defaults = UserDefaults.standard
                defaults.set(encoded, forKey: "saveUser")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view
        self.setUpLocationServices()
        self.tableViewWatch.delegate = self
        self.tableViewWatch.dataSource = self
    }
    
    func updateData(device: Watch) {
        let index = self.user?.devices?.firstIndex(where: {$0.uid == device.uid})
        if (index != nil) {
            self.user?.devices?[index!] = device
            self.tableViewWatch.reloadRows(at: [IndexPath(row: index!, section: 0)], with: .automatic)
        }
    }
    @IBAction func btnAddDevice(sender: Any) {
        let viewController = BarcodeScannerViewController()
        viewController.codeDelegate = self
        viewController.errorDelegate = self
        viewController.dismissalDelegate = self

        present(viewController, animated: true, completion: nil)
        
//        let sender = PushNotificationSender()
//        sender.sendPushNotification(to: "eYIAx0uShklRvYnEKSlouj:APA91bG2X3jzQEO01ou8SzPUF7kCqfAiPgH4awvvXpy6Uvh1FdhjrPcIZOGL3yIhcZ7PKa6jf_jBPsAT9_W6NdhCDTKuhqlwRZYTKXon0FfbvhYAp-xfM3hmJq2bkBGLUPxpH55azhOX", title: "Your card has arrived", body: "Your card has arrived")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.user?.devices?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tablecell") as! tablecell
        let watch = self.user?.devices?[indexPath.row]
        cell.watchName.text = watch?.name
        cell.lblDistance.text = watch?.unit
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
}
extension HomeVc: BarcodeScannerCodeDelegate {
  func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
    print(code)
    controller.reset()
      self.devicesRef.child(code).observeSingleEvent(of: .value, with: { snapshot in
          guard let value = snapshot.value else { return }
          do {
              let device = try FirebaseDecoder().decode(Watch.self, from: value)
              let isExist = self.user?.devices?.filter({$0.uid == device.uid}).count ?? 0 > 0
              if isExist {
                  Alertift.alert(title: "SafeSync Error", message: "Device Already Exist")
                      .action(.default("OK"))
                      .show(on: self)
                  return
              }
              self.user?.devices?.append(device)
              
              let data = try! FirebaseEncoder().encode(self.user)
              self.usersRef.child(self.user?.usid ?? "0").setValue(data)
              
              self.collectLocation(location: self.userLocation!)
              self.tableViewWatch.reloadData()
              
          } catch let error {
              print(error)
          }
      })
      controller.dismiss(animated: true, completion: nil)
  }
}
extension HomeVc: BarcodeScannerDismissalDelegate {
  func scannerDidDismiss(_ controller: BarcodeScannerViewController) {
    controller.dismiss(animated: true, completion: nil)
  }
}
extension HomeVc: BarcodeScannerErrorDelegate {
  func scanner(_ controller: BarcodeScannerViewController, didReceiveError error: Error) {
    print(error)
  }
}
