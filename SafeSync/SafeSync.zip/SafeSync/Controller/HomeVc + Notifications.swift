//
//  HomeVc + Notifications.swift
//  SafeSync
//
//  Created by Attique Ullah on 10/02/2022.
//

import Foundation
import Firebase
import FirebaseMessaging
import Alertift
extension HomeVc {
    func sendPushNotifications(device: Watch) {
        if device.distance ?? 0.0 <= 100.0 {
            /// Send Notification
            let queue = OperationQueue()
            queue.qualityOfService = .userInitiated
            queue.maxConcurrentOperationCount = 1
            
            var operations:[NotificationOperation] = []
            let operation = NotificationOperation(to: device.token, title: "Your car has arrived", body: "Your car has arrived")
            operations.append(operation)
            
            handleViewsStateForOperations(operations: operations, onOperationQueue: queue)
            queue.addOperations(operations, waitUntilFinished: false)
        }
    }
    private func handleViewsStateForOperations(operations:[Operation], onOperationQueue queue:OperationQueue) {
        operations.forEach { operation in
            switch operation {
                /* ------------------------------------------------------------------------------------------------------------ */
                //MARK: Start New Conversation Operation completion
                case let operation as NotificationOperation:
                    operation.completionBlock = {
                        guard case let .success(status) = operation.result else {
                            if case let .failure(error) = operation.result {
                                print(error)
                            }
                            return
                        }
                        print("Notification Status \(status)")
                }
                default: break
            }
        }
    }
}
