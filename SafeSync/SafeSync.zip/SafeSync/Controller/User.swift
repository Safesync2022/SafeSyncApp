//
//  User.swift
//  SafeSync
//
//  Created by Attique Ullah on 02/02/2022.
//

import Foundation
struct User : Codable {
    var usid: String?
    var firstName: String?
    var lastName: String?
    var mobile: String?
    var email: String?
    var devices: [Watch]?
}
