//
//  SignInVc.swift
//  SafeSync
//
//  Created by M Usman Haider on 24/01/2022.
//

import UIKit
import Firebase
import KRProgressHUD
import CodableFirebase

class SignInVc: UIViewController {

    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passTxt: UITextField!
    
    let usersRef = Database.database().reference(withPath: "users")
    var user: User = User() {
        didSet {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(user) {
                let defaults = UserDefaults.standard
                defaults.set(encoded, forKey: "saveUser")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func signIn(_ sender: UIButton) {
        signin()
        
    }
    func signin() {
        guard
          let email = emailTxt.text,
          let password = passTxt.text,
          !email.isEmpty,
          !password.isEmpty
        else { return }

        KRProgressHUD.show(withMessage: "Please wait...")
        Auth.auth().signIn(withEmail: email, password: password) { user, error in
          if let error = error, user == nil {
            let alert = UIAlertController(
              title: "Sign In Failed",
              message: error.localizedDescription,
              preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true, completion: nil)
              
          }else{
              self.usersRef.child(user?.user.uid ?? "").observeSingleEvent(of: .value, with: { snapshot in
                  guard let value = snapshot.value else { return }
                  do {
                      KRProgressHUD.dismiss()
                      var model = try FirebaseDecoder().decode(User.self, from: value)
                      if model.devices == nil {
                          model.devices = [Watch]()
                      }
                      self.user = model
                      
                      self.performSegue(withIdentifier: "main", sender: self.user)
                      
                  } catch let error {
                      print(error)
                  }
              })
          }
        }
    }
    

}
