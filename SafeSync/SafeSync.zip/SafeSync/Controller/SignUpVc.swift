//
//  SignUpVc.swift
//  SafeSync
//
//  Created by M Usman Haider on 24/01/2022.
//

import UIKit
import Firebase
import KRProgressHUD
import CodableFirebase
import Toast
class SignUpVc: UIViewController {
    
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var lastnameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passTxt: UITextField!
    @IBOutlet weak var mobileTxt: UITextField!
    @IBOutlet weak var DateOfBirthTxt: UITextField!
    
    let usersRef = Database.database().reference(withPath: "users")
    var user: User = User()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signUp(_ sender: UIButton) {
        signUp()
    }
    
    func signUp() {
        guard
          let email = emailTxt.text,
          let password = passTxt.text,
          !email.isEmpty,
          !password.isEmpty
        else { return }

        KRProgressHUD.show(withMessage: "Please wait...")
        Auth.auth().createUser(withEmail: email, password: password) { auth, error in
          if error == nil {
              KRProgressHUD.dismiss()
              self.user.usid = auth?.user.uid
              self.user.firstName = self.nameTxt.text
              self.user.lastName = self.lastnameTxt.text
              self.user.mobile = self.mobileTxt.text
              self.user.email = self.emailTxt.text
              self.user.devices = []
              
              let data = try! FirebaseEncoder().encode(self.user)
              self.usersRef.child(auth?.user.uid ?? "0").setValue(data)
              
              self.view.makeToast("Register Sucessfull.")
              self.navigationController?.popViewController(animated: true)
          } else {
            print("Error in createUser: \(error?.localizedDescription ?? "")")
          }
        }
    }
}
