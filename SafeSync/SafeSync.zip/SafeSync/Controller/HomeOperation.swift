//
//  HomeOperation.swift
//  SafeSync
//
//  Created by Attique Ullah on 10/02/2022.
//

import Foundation
import os
import CoreLocation
import GeoFire
import Firebase
class HomeOperation: Operation {
    var result: Result<Watch, APIError>?
    
    private var downloading = false
    
    var watch:Watch
    private let userLocation:CLLocation
    
    init(watch: Watch, location: CLLocation) {
        self.watch = watch
        self.userLocation = location
    }
    
    override var isAsynchronous: Bool {
        return true
    }
    
    override var isExecuting: Bool {
        return downloading
    }
    
    override var isFinished: Bool {
        return result != nil
    }
    
    override func cancel() {
        super.cancel()
        
    }
    
    func finish(result: CLLocation) {
       
        willChangeValue(forKey: #keyPath(isExecuting))
        willChangeValue(forKey: #keyPath(isFinished))
        
        downloading = false
    
        let userRadius = userLocation.distance(from: result)
        self.watch.distance = userRadius
        
        self.result = .success(watch)
        
        didChangeValue(forKey: #keyPath(isFinished))
        didChangeValue(forKey: #keyPath(isExecuting))
    }
    
    override func start() {
        willChangeValue(forKey: #keyPath(isExecuting))
        downloading = true
        didChangeValue(forKey: #keyPath(isExecuting))
        
        guard !isCancelled else {
            return
        }
        
        let geofireRef = Database.database().reference(withPath: "Locations")
        let geoFire = GeoFire(firebaseRef: geofireRef)
        
        geoFire.getLocationForKey(self.watch.uid) { (location, error) in
          if (error != nil) {
              print("An error occurred getting the location for \"firebase-hq\": \(error?.localizedDescription)")
          } else if (location != nil) {
              self.finish(result: location!)
          } else {
            print("GeoFire does not contain a location for \"firebase-hq\"")
          }
        }
    }
}
class NotificationOperation: Operation {
    var result: Result<Bool, APIError>?
    
    private var downloading = false
    
    private var token:String
    private let title:String
    private let body:String
    
    init(to token: String, title: String, body: String) {
        self.token = token
        self.title = title
        self.body = body
    }
    
    override var isAsynchronous: Bool {
        return true
    }
    
    override var isExecuting: Bool {
        return downloading
    }
    
    override var isFinished: Bool {
        return result != nil
    }
    
    override func cancel() {
        super.cancel()
        
    }
    
    func finish(result: Bool) {
       
        willChangeValue(forKey: #keyPath(isExecuting))
        willChangeValue(forKey: #keyPath(isFinished))
        
        self.result = .success(result)
        
        didChangeValue(forKey: #keyPath(isFinished))
        didChangeValue(forKey: #keyPath(isExecuting))
    }
    
    override func start() {
        willChangeValue(forKey: #keyPath(isExecuting))
        downloading = true
        didChangeValue(forKey: #keyPath(isExecuting))
        
        guard !isCancelled else {
            return
        }
        
        let sender = PushNotificationSender()
        sender.sendPushNotification(to: self.token, title: self.title, body: self.body)
        
    }
}
enum APIError: Error {
    static let commonErrorDescription = "Something went wrong. Please try again later."
    
    case cancelled
    case invalidURL
    case jsonDecodingError(error: Error, data:Data)
    case networkError(error: Error)
    case resultError(message: String)
}
