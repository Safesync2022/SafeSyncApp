//
//  Model.swift
//  SafeSync
//
//  Created by M Usman Haider on 24/01/2022.
//

import Foundation
