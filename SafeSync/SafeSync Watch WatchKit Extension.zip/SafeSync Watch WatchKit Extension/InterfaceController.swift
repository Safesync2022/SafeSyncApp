//
//  InterfaceController.swift
//  SafeSync Watch WatchKit Extension
//
//  Created by Attique Ullah on 02/02/2022.
//
import UIKit
import WatchKit
import Foundation
import EFQRCode
import Firebase
import CodableFirebase
import CoreLocation
//import SwiftLocation

class InterfaceController: WKInterfaceController, CLLocationManagerDelegate {

    @IBOutlet weak var mainLabel: WKInterfaceLabel!
    @IBOutlet weak var qrImage: WKInterfaceImage!
    
    var locationManager = CLLocationManager()
    let usersRef = Database.database().reference(withPath: "Devices")
    
    var watch: Watch? {
        get {
            let defaults = UserDefaults.standard
            if let savedPerson = defaults.object(forKey: "userWatch") as? Data {
                let decoder = JSONDecoder()
                if let loadedPerson = try? decoder.decode(Watch.self, from: savedPerson) {
                    return loadedPerson
                }
            }
            return Watch(uid: WKInterfaceDevice.current().identifierForVendor!.uuidString, name: WKInterfaceDevice.current().name, model: WKInterfaceDevice.current().model, token: UserDefaults.standard.string(forKey: "fcmToken") ?? "")
        }
        set {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(newValue) {
                let defaults = UserDefaults.standard
                defaults.set(encoded, forKey: "userWatch")
            }
        }
    }
    
    
    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        if let image = EFQRCode.generate(for: watch?.uid ?? "") {
            print("Create QRCode image success \(image)")
            qrImage.setImage(UIImage(cgImage: image))
        } else {
            print("Create QRCode image failed!")
        }

        //let data = try! FirebaseEncoder().encode(self.watch)
        //self.usersRef.child(watch?.uid ?? "").setValue(data)
        
        setUpLocationServices()
        
        NotificationCenter.default.addObserver(self,selector: #selector(doSomeThing), name: WKExtension.applicationDidBecomeActiveNotification, object: nil)
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }
    /*func setUpLocationServices() {
        
        self.serviceOptions.accuracy = GPSLocationOptions.Accuracy.city
        self.serviceOptions.activityType = .fitness
        self.serviceOptions.precise = .reducedAccuracy
        self.serviceOptions.minDistance = CLLocationDistance(0)
        self.serviceOptions.subscription = .continous
        
        SwiftLocation.requestAuthorization(.onlyInUse) { [weak self] newStatus in
            switch newStatus {
            case .authorizedWhenInUse:self?.createLocationRequest()
            case .notDetermined: break
            case .denied:self?.displayLocationAlert()
            case .authorizedAlways:self?.createLocationRequest()
            case .restricted:self?.displayLocationAlert()
            @unknown default:
                break
            }
        }

    }
    private func createLocationRequest(){
        
        let request = SwiftLocation.gpsLocationWith(serviceOptions)
        request.then(queue: .main) { result in
            switch result {
            case .success(let visit):break
            case .failure(let error):print(error)
            }
        }
    }
    private func displayLocationAlert(){
        let h0 = { print("ok")}
        let action1 = WKAlertAction(title: "Ok", style: .default, handler:h0)

            presentAlert(withTitle: "Location Services Disabled", message: "Would you like to change this in settings?", preferredStyle: .actionSheet, actions: [action1])
    }*/
}
