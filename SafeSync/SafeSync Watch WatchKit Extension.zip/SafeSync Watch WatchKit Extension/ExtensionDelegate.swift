//
//  ExtensionDelegate.swift
//  SafeSync Watch WatchKit Extension
//
//  Created by Attique Ullah on 02/02/2022.
//

import WatchKit
import CodableFirebase
import Foundation
import Firebase
import FirebaseMessaging
import UserNotifications

class ExtensionDelegate: NSObject, WKExtensionDelegate, MessagingDelegate, UNUserNotificationCenterDelegate  {
    
    
    var watch: Watch? {
        get {
            let defaults = UserDefaults.standard
            if let savedPerson = defaults.object(forKey: "userWatch") as? Data {
                let decoder = JSONDecoder()
                if let loadedPerson = try? decoder.decode(Watch.self, from: savedPerson) {
                    return loadedPerson
                }
            }
            return nil
        }
        set {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(newValue) {
                let defaults = UserDefaults.standard
                defaults.set(encoded, forKey: "userWatch")
                
                let usersRef = Database.database().reference(withPath: "Devices")
                let data = try! FirebaseEncoder().encode(newValue)
                usersRef.child(watch?.uid ?? "").setValue(data)
            }
        }
    }
    
    func applicationDidFinishLaunching() {
        FirebaseApp.configure()
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.alert, .sound,.badge]) { granted, _ in
          if granted {
            WKExtension.shared().registerForRemoteNotifications()
          }
        }
        Messaging.messaging().delegate = self
        
        // Perform any final initialization of your application.
    }

    func applicationDidBecomeActive() {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillResignActive() {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, etc.
    }

    func handle(_ backgroundTasks: Set<WKRefreshBackgroundTask>) {
        // Sent when the system needs to launch the application in the background to process tasks. Tasks arrive in a set, so loop through and process each one.
        for task in backgroundTasks {
            // Use a switch statement to check the task type
            switch task {
            case let backgroundTask as WKApplicationRefreshBackgroundTask:
                // Be sure to complete the background task once you’re done.
                backgroundTask.setTaskCompletedWithSnapshot(false)
            case let snapshotTask as WKSnapshotRefreshBackgroundTask:
                // Snapshot tasks have a unique completion call, make sure to set your expiration date
                snapshotTask.setTaskCompleted(restoredDefaultState: true, estimatedSnapshotExpiration: Date.distantFuture, userInfo: nil)
            case let connectivityTask as WKWatchConnectivityRefreshBackgroundTask:
                // Be sure to complete the connectivity task once you’re done.
                connectivityTask.setTaskCompletedWithSnapshot(false)
            case let urlSessionTask as WKURLSessionRefreshBackgroundTask:
                // Be sure to complete the URL session task once you’re done.
                urlSessionTask.setTaskCompletedWithSnapshot(false)
            case let relevantShortcutTask as WKRelevantShortcutRefreshBackgroundTask:
                // Be sure to complete the relevant-shortcut task once you're done.
                relevantShortcutTask.setTaskCompletedWithSnapshot(false)
            case let intentDidRunTask as WKIntentDidRunRefreshBackgroundTask:
                // Be sure to complete the intent-did-run task once you're done.
                intentDidRunTask.setTaskCompletedWithSnapshot(false)
            default:
                // make sure to complete unhandled task types
                task.setTaskCompletedWithSnapshot(false)
            }
        }
    }
    
    /// MessagingDelegate
    func messaging(_: Messaging, didReceiveRegistrationToken fcmToken: String?) {
      print("token:\n" + fcmToken!)
     
      Messaging.messaging().subscribe(toTopic: "watch") { error in
        guard error == nil else {
          print("error:" + error.debugDescription)
          return
        }
        print("Successfully subscribed to topic")
      }
        UserDefaults.standard.set(fcmToken ?? "", forKey: "fcmToken")
        self.watch = Watch(uid: WKInterfaceDevice.current().identifierForVendor!.uuidString, name: WKInterfaceDevice.current().name, model: WKInterfaceDevice.current().model, token: fcmToken ?? "")
    }
    
    /// WKExtensionDelegate
    func didRegisterForRemoteNotifications(withDeviceToken deviceToken: Data) {
      /// Swizzling should be disabled in Messaging for watchOS, set APNS token manually.
      print("Set APNS Token\n")
        
      Messaging.messaging().apnsToken = deviceToken
    }
    
    func didFailToRegisterForRemoteNotificationsWithError(_ error: Error) {
        print(error)
        self.watch = Watch(uid: WKInterfaceDevice.current().identifierForVendor!.uuidString, name: WKInterfaceDevice.current().name, model: WKInterfaceDevice.current().model, token: UserDefaults.standard.string(forKey: "fcmToken") ?? "")
    }
    
    func didReceiveRemoteNotification(_ userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (WKBackgroundFetchResult) -> Void) {
        
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.sound,.banner,.alert])
    }

}
