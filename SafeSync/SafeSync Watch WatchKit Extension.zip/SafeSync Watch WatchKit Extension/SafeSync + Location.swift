//
//  SafeSync + Location.swift
//  SafeSync Watch WatchKit Extension
//
//  Created by Attique Ullah on 09/02/2022.
//

import Foundation
import WatchKit
import CoreLocation
import GeoFire
extension InterfaceController {
    
    func setUpLocationServices() {
        self.locationManager.delegate = self
        self.locationManager.activityType = .fitness
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.allowsBackgroundLocationUpdates = true
        

        if CLLocationManager.locationServicesEnabled() {
            switch locationManager.authorizationStatus {
            case .notDetermined:
                self.locationManager.requestAlwaysAuthorization()
            case .denied, .restricted:
                displayLocationAlert()
            case .authorizedAlways, .authorizedWhenInUse:
                self.locationManager.startUpdatingLocation()
            @unknown default:
                //Do nothing
                locationManager.requestAlwaysAuthorization()
            }
        } else {
            self.locationManager.requestAlwaysAuthorization()
        }
    }
    
    private func displayLocationAlert(){
        let h0 = { print("ok")}
        let action1 = WKAlertAction(title: "Ok", style: .default, handler:h0)

        presentAlert(withTitle: "Location Services Disabled", message: "Would you like to change this in settings?", preferredStyle: .actionSheet, actions: [action1])
    }
    
    private func collectLocation(location: CLLocation){
        let geofireRef = Database.database().reference(withPath: "Locations")
        let geoFire = GeoFire(firebaseRef: geofireRef)
        geoFire.setLocation(CLLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude), forKey: self.watch?.uid ?? "")
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let mostRecentLocation = locations.last {
            print("mostRecentLocation: \(mostRecentLocation)")
            collectLocation(location: mostRecentLocation)
        }
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if let mostRecentLocation = self.locationManager.location {
            collectLocation(location: mostRecentLocation)
        }
    }
    @objc func doSomeThing(){
        if CLLocationManager.locationServicesEnabled() {
            switch locationManager.authorizationStatus {
            case .notDetermined:
                break
            case .denied, .restricted:
                break
            case .authorizedAlways, .authorizedWhenInUse:
                self.locationManager.startUpdatingLocation()
            @unknown default:
                //Do nothing
                break
            }
        } else {
    
        }
    }
    
}
