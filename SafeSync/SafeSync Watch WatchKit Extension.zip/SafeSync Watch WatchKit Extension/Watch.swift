//
//  Watch.swift
//  SafeSync Watch WatchKit Extension
//
//  Created by Attique Ullah on 04/02/2022.
//

import Foundation

struct Watch : Codable {
    let uid: String
    let name: String
    let model: String
    let token: String
    var distance: Double? = 0.0
    
    var unit: String {
        let measurement = Measurement(value: self.distance ?? 0.0, unit: UnitLength.meters).converted(to: .kilometers)

        let mf = MeasurementFormatter()
        mf.unitOptions = .providedUnit
        mf.unitStyle = .medium
        mf.numberFormatter.maximumFractionDigits = 1
        return mf.string(from: measurement)   // "0.1 km"
    }
}
